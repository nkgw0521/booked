insert into `dbversion` values('2.7', now());
insert into `payment_configuration` (`credit_cost`, `credit_currency`) values(0, 'USD');