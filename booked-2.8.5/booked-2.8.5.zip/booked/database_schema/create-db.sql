DROP DATABASE IF EXISTS `booked`;

CREATE DATABASE `booked`;

USE `booked`;