<?php

require_once(ROOT_DIR . 'lib/Common/SmartyControls/SmartyTextbox.php');
