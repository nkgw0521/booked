<?php

class GlobalKeys
{
	const TIMEZONES = 'APP_TIMEZONES';
}
