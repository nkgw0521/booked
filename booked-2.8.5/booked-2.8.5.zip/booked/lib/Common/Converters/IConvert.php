<?php

interface IConvert
{
	public function Convert($value);
}
