<?php

require_once(ROOT_DIR . 'lib/Common/Converters/IConvert.php');
require_once(ROOT_DIR . 'lib/Common/Converters/BooleanConverter.php');
require_once(ROOT_DIR . 'lib/Common/Converters/IntConverter.php');
require_once(ROOT_DIR . 'lib/Common/Converters/LowerCaseConverter.php');
