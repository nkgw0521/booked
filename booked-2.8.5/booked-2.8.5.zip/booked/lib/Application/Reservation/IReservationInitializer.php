<?php

interface IReservationInitializer
{
	public function Initialize();
}
