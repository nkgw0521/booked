<?php

require_once(ROOT_DIR . 'lib/Application/Authorization/PermissionService.php');
require_once(ROOT_DIR . 'lib/Application/Authorization/PermissionServiceFactory.php');
require_once(ROOT_DIR . 'lib/Application/Authorization/ResourcePermissionStore.php');
require_once(ROOT_DIR . 'lib/Application/Authorization/AuthorizationServiceFactory.php');
require_once(ROOT_DIR . 'lib/Application/Authorization/AuthorizationService.php');
require_once(ROOT_DIR . 'lib/Application/Authorization/GuestPermissionServiceFactory.php');
