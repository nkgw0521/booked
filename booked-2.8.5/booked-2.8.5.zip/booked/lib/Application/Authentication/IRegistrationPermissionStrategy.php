<?php

interface IRegistrationPermissionStrategy
{
	public function AddAccount(User $user);
}
