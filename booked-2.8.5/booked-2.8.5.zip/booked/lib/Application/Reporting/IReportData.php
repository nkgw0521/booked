<?php

interface IReportData
{
	/**
	 * @return array
	 */
	public function Rows();
}
