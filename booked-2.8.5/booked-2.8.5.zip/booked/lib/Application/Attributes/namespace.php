<?php

require_once(ROOT_DIR . 'lib/Application/Attributes/Attribute.php');
require_once(ROOT_DIR . 'lib/Application/Attributes/AttributeList.php');
require_once(ROOT_DIR . 'lib/Application/Attributes/AttributeService.php');
require_once(ROOT_DIR . 'lib/Application/Attributes/AttributeFormParser.php');
require_once(ROOT_DIR . 'lib/Application/Attributes/AttributeValidator.php');
