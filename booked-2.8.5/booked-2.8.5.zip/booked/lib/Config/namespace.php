<?php

require_once(ROOT_DIR . 'lib/Config/ConfigKeys.php');
require_once(ROOT_DIR . 'lib/Config/Configuration.php');
