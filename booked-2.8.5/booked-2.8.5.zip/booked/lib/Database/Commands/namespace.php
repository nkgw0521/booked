<?php

require_once(ROOT_DIR . 'lib/Database/Commands/Commands.php');
require_once(ROOT_DIR . 'lib/Database/Commands/Queries.php');
require_once(ROOT_DIR . 'lib/Database/Commands/ParameterNames.php');
require_once(ROOT_DIR . 'lib/Database/Commands/ColumnNames.php');
require_once(ROOT_DIR . 'lib/Database/Commands/TableNames.php');
