<?php

require_once(ROOT_DIR . 'lib/Database/namespace.php');
require_once(ROOT_DIR . 'lib/Database/MySQL/MySqlCommandAdapter.php');
require_once(ROOT_DIR . 'lib/Database/MySQL/MySqlReader.php');
require_once(ROOT_DIR . 'lib/Database/MySQL/MySqlConnection.php');
