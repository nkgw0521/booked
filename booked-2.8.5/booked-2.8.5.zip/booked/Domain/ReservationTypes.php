<?php

class ReservationTypes
{
	const Reservation = 1;
	const Blackout = 2;
}
