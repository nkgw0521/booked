<?php

class InvitationAction
{
	const Accept = 'accept';
	const CancelAll = 'cancelAll';
	const CancelInstance = 'cancelInstance';
	const Decline = 'decline';
	const Join = 'join';
	const JoinAll = 'joinAll';
}
