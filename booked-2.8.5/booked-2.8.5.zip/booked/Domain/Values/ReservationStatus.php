<?php

class ReservationStatus
{
	const Created = 1;
	const Deleted = 2;
	const Pending = 3;
}
