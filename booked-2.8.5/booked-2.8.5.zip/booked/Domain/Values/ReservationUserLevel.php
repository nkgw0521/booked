<?php

class ReservationUserLevel
{
	public function __construct()
	{
	}

	const ALL = 0;
	const OWNER = 1;
	const PARTICIPANT = 2;
	const INVITEE = 3;
}
