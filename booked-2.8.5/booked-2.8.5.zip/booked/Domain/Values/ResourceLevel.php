<?php

class ResourceLevel
{
	const Primary = 1;
	const Additional = 2;
}
