<?php

class ResourcePermissionType
{
    const None = -1;
    const Full = 0;
    const View = 1;
}
